import { useState } from "react"
import { Data } from "./Data"


const Search = () => {

    const [store, setStore] = useState(Data)


    return (

        <div className="container">
            <input
                type="text"
                placeholder="Search Here..."
            />

            <div className="type">
                <h3>Name</h3>
                <h3>Type</h3>
                <h3>Images</h3>
            </div>

            {
                store.map ((cur) => //cur = current item in the array
                {

                    return (
                        <div className="itemCard">
                            <p>cur.name</p>
                            <p>cur.type</p>
                            <img 
                                src={cur.img} 
                                // alt={cur.name}
                            />
                        </div>
                    )
                })
            }
        </div>
    )
}
export default Search