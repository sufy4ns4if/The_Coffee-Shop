// import affogato from "./Data_imgs/GPT individual_coffee_pictures/affogato.png";
import affogato from "/Visual Studio Code Files/Personal Projects/TheCoffeeShop/src/Components/Data_imgs/GPT individual_coffee_pictures/affogato.png";
// import americano from "./Data_imgs/GPT individual_coffee_pictures/americano.png";
// import cappuccino from "./Data_imgs/GPT individual_coffee_pictures/cappuccino.png";
// import cortado from "./Data_imgs/GPT individual_coffee_pictures/cortado.png";
// import doppio from "./Data_imgs/GPT individual_coffee_pictures/doppio.png";
// import espresso from "./Data_imgs/GPT individual_coffee_pictures/espresso.png";
// import espresso_martini from "./Data_imgs/GPT individual_coffee_pictures/espresso_martini.png";
// import flat_white from "./Data_imgs/GPT individual_coffee_pictures/flat_white.png";
// import irish_coffee from "./Data_imgs/GPT individual_coffee_pictures/irish_coffee.png";
// import latte from "./Data_imgs/GPT individual_coffee_pictures/latte.png";
// import lungo from "./Data_imgs/GPT individual_coffee_pictures/lungo.png";
// import macchiato from "./Data_imgs/GPT individual_coffee_pictures/macchiato.png";
// import mocha from "./Data_imgs/GPT individual_coffee_pictures/mocha.png";
// import red_eye from "./Data_imgs/GPT individual_coffee_pictures/red_eye.png";
// import ristretto from "./Data_imgs/GPT individual_coffee_pictures/ristretto.png";
// import vienna from "./Data_imgs/GPT individual_coffee_pictures/vienna.png";


export default Data = [

    {
        name: "affogato",
        type: "Hot, Cold",
        img: affogato
    },
    {
        name: "americano",
        type: "Hot",
        img: americano
    },
    {
        name: "Cappuccino",
        type: "Hot, Cold",
        img: cappuccino
    },
    {
        name: "Cortado",
        type: "Hot, Cold",
        img: cortado
    },
    {
        name: "doppio",
        type: "Cold",
        img: doppio
    },
    {
        name: "espresso",
        type: "Hot, Cold",
        img: espresso
    },
    {
        name: "espresso martini",
        type: "Hot, Cold",
        img: espresso_martini
    },
    {
        name: "flat white",
        type: "Hot, Cold",
        img: flat_white
    },
    {
        name: "irish-coffee",
        type: "Hot, Cold",
        img: irish-coffee
    },
    {
        name: "latte",
        type: "Extra Hot, Hot, Warm, Cold",
        img: latte
    },
    {
        name: "lungo",
        type: "Hot, Cold",
        img: lungo
    },
    {
        name: "macchiato",
        type: "Hot, Cold",
        img: macchiato
    },
    {
        name: "mocha",
        type: "Hot, Cold, Iced",
        img: mocha
    },
    {
        name: "red-eye",
        type: "Hot, Cold",
        img: red-eye
    },
    {
        name: "ristretto",
        type: "Hot, Cold",
        img: ristretto
    },
    {
        name: "vienna",
        type: "Hot, Cold",
        img: vienna
    },


]